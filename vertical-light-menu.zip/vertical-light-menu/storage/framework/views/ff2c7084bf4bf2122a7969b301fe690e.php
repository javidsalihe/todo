<?php $__env->startSection('styles'); ?>

    <!--  BEGIN CUSTOM STYLE FILE  -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/light/assets/pages/error/style-maintanence.scss']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/dark/assets/pages/error/style-maintanence.scss']); ?>

    <style>
        body.layout-dark .theme-logo.dark-element {
            display: inline-block;
        }
        .theme-logo.dark-element {
            display: none;
        }
        body.layout-dark .theme-logo.light-element {
            display: none;
        }
        .theme-logo.light-element {
            display: inline-block;
        }
    </style>

    <!--  END CUSTOM STYLE FILE  -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid maintanence-content">
    <div class="">
        <div class="maintanence-hero-img">
            <a href="/dashboard/analytics">
                <img alt="logo" src="<?php echo e(Vite::asset('resources/images/logo.svg')); ?>" class="dark-element theme-logo">
                <img alt="logo" src="<?php echo e(Vite::asset('resources/images/logo2.svg')); ?>" class="light-element theme-logo">
            </a>
        </div>
        <h1 class="error-title">Under Maintenance</h1>
        <p class="error-text">Thank you for visiting us.</p>
        <p class="text">We are currently working on making some improvements <br/> to give you better user experience.</p>
        <p class="text">Please visit us again shortly.</p>
        <a href="/dashboard/analytics" class="btn btn-dark mt-4">Home</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work Station\cork-v3.9.0\laravel\vertical-light-menu\resources\views/admin/pages/maintenance.blade.php ENDPATH**/ ?>