<?php $__env->startSection('styles'); ?>

<?php echo app('Illuminate\Foundation\Vite')(['resources/scss/light/assets/authentication/auth-boxed.scss']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/scss/dark/assets/authentication/auth-boxed.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="auth-container d-flex h-100">

    <div class="container mx-auto align-self-center">

        <div class="row">

            <div class="col-xxl-4 col-xl-5 col-lg-5 col-md-8 col-12 d-flex flex-column align-self-center mx-auto">
                <div class="card mt-3 mb-3">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-12 mb-3">
                                
                                <h2>Password Reset</h2>
                                <p>Enter your email to recover your ID</p>
                                
                            </div>
                            <div class="col-md-12">
                                <div class="mb-4">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mb-4">
                                    <button class="btn btn-secondary w-100">RECOVER</button>
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>
            </div>
            
        </div>
        
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work Station\cork-v3.9.0\laravel\vertical-light-menu\resources\views/admin/auth/boxed/reset.blade.php ENDPATH**/ ?>