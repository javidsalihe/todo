// import './import.plugins';
import.meta.glob([
    '../images/**',
]);